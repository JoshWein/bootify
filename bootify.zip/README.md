# bootify
Chrome Extension that injects bootstrap style into any page.

Chrome Store: https://chrome.google.com/webstore/detail/bootify/ekbicbimdmfoehanpahkcajejciloahj?hl=en

## How to use
*  Go to the options to add a website for the extension to run on automatically or click the extension to add bootstrap to the current page.

## Planned Features [Feel free to fork and do it yourself]
*  Ability to save websites through context menu.
